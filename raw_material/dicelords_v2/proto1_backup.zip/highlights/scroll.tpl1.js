var 
LOOK = {
	'size' : [110, 150],
	'up' : 'alf.gif', 
	'dn' : 'art.gif'
},

BEHAVE = {
	'auto'  : true, 
	'vertical' : false, 
	'speed' : 5
},


ITEMS = [
	{
		'file': '',
		'content': '<A href="http://www.segasys.com" target="_blank"><IMG src="segasys.jpg" width="104" height="150" border="0"></A>',
		'pause_b': 0,
		'pause_a': 5
	},
	{
		'file' : '',
		'content' : '<A href="http://www.muktagiri.com" target="_blank"><IMG src="muktagiri.jpg" width="104" height="150" border="0"></A>',
		'pause_b' : 0,
		'pause_a' : 5
	},
	{
		'file': '',
		'content': '<A href="http://www.rincon.co.in" target="_blank"><IMG src="rincon.jpg" width="104" height="150" border="0"></A>',
		'pause_b': 0,
		'pause_a': 5
	},
	{
		'file' : '',
		'content' : '<A href="http://www.f1manager.50megs.com" target="_blank"><IMG src="f1.jpg" width="104" height="150" border="0"></A>',
		'pause_b' : 0,
		'pause_a' : 5
	},
	{
		'file' : '',
		'content' : '<A href="http://www.dicelords.com/d1" target="_blank"><IMG src="dicelords.jpg" width="104" height="150" border="0"></A>',
		'pause_b' : 0,
		'pause_a' : 5
	}
]
