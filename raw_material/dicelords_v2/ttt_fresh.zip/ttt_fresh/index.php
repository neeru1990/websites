<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>
<HEAD>
<BASE href="http://www.dicelords.com/ttt/">
<TITLE>Dicelords Interactive > Tic Tac Toe 2003</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<LINK href="css/main.css" type=text/css rel=stylesheet>
</HEAD>
<BODY>
<TABLE width="100%" border="0" cellpadding="0" cellspacing="0">
  <TR> 
    <TD width="605" height="40" bgcolor="#65707C"> <A href="http://www.dicelords.com" target="_parent"><IMG src="images/logo.gif" alt="Dicelords Interactive" width="200" height="14" border="0"></A> 
    </TD>
    <TD width="25%" bgcolor="#65707C" class="date"> <SCRIPT language=JavaScript src="js/date.js" type=text/javascript></SCRIPT> 
    </TD>
  </TR>
  <TR> 
    <TD colspan="2" class="punchline">we know the rules of the game.</TD>
  </TR>
</TABLE>
&nbsp;
<TABLE width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
  <TR align="left" valign="top">
    <TD width="20%"><CENTER>
        <IMG src="images/x&o.gif" width="126" height="124"> </CENTER>
      </TD>
    <TD width="5%">&nbsp; </TD>
    <TD width="75%"> 
      <H1>Overview</H1>
      <P> Welcome to the classic game of Tic-Tac-Toe. This simple game is played 
        on a 3 x 3 grid. Each player takes a choice of either X or O, then using 
        only wit, try to creat a simple line of 3 of their respective symbol. 
        Whoever does so first, wins. If all the squares are filled, but no lines 
        created, a draw is the result. The game was completely built in C++ and 
        incorporates GUI and mouse enviornments.&nbsp; </P>
      <H1>System Requirements</H1>
      <P>1. Pentium 1 MMX - 166 MHz or higher based system<BR>
	2. Windows 9x, Me, NT, 2000 or XP<BR>
        3. VGA, SuperVGA or compatible video adapter<BR>
        4. 200KB of Hard Drive Space<BR>
        5. Mouse &amp; Keyboard</P>
      <H1>Downloads</H1>
      <TABLE width="100%" height="200" border="1" cellpadding="0" cellspacing="0" bordercolor="#eeeeee">
        <TR bgcolor="#999999"> 
          <TD width="50%"> <CENTER>
              <FONT color="#FFFFFF" size="2"><STRONG>Features</STRONG></FONT> 
            </CENTER></TD>
          <TD width="25%"> <CENTER>
              <FONT color="#FFFFFF" size="2"><STRONG>Demo</STRONG></FONT> </CENTER></TD>
          <TD width="25%"> <CENTER>
              <FONT color="#FFFFFF" size="2"><STRONG>Version 1.0</STRONG></FONT> 
            </CENTER></TD>
        </TR>
        <TR> 
          <TD>1 Player Game</TD>
          <TD><CENTER>
              <IMG src="images/bullet.gif" width="5" height="7"> </CENTER></TD>
          <TD><CENTER>
              <IMG src="images/bullet.gif" width="5" height="7"> </CENTER></TD>
        </TR>
        <TR> 
          <TD>2 Player Game</TD>
          <TD>&nbsp;</TD>
          <TD><CENTER>
              <IMG src="images/bullet.gif" width="5" height="7"> </CENTER></TD>
        </TR>
        <TR> 
          <TD>Quick Game mode</TD>
          <TD><CENTER>
              <IMG src="images/bullet.gif" width="5" height="7"> </CENTER></TD>
          <TD><CENTER>
              <IMG src="images/bullet.gif" width="5" height="7"> </CENTER></TD>
        </TR>
        <TR> 
          <TD>Tournament mode</TD>
          <TD>&nbsp;</TD>
          <TD><CENTER>
              <IMG src="images/bullet.gif" width="5" height="7"> </CENTER></TD>
        </TR>
        <TR> 
          <TD>Statistics Report</TD>
          <TD>&nbsp;</TD>
          <TD><CENTER>
              <IMG src="images/bullet.gif" width="5" height="7"> </CENTER></TD>
        </TR>
        <TR> 
          <TD>Difficulty Levels</TD>
          <TD>&nbsp;</TD>
          <TD><CENTER>
              <IMG src="images/bullet.gif" width="5" height="7"> </CENTER></TD>
        </TR>
        <TR> 
          <TD> Human-like Artificial Intelligence Design</TD>
          <TD>&nbsp;</TD>
          <TD><CENTER>
              <IMG src="images/bullet.gif" width="5" height="7"> </CENTER></TD>
        </TR>
        <TR> 
          <TD> File Size</TD>
          <TD><CENTER>
              84 KB 
            </CENTER></TD>
          <TD><CENTER>
              90 KB 
            </CENTER></TD>
        </TR>
        <TR> 
          <TD>&nbsp;</TD>
          <TD> <CENTER>
              <STRONG> <A href="download/ttt2003_demo.exe">DOWNLOAD</A></STRONG> 
            </CENTER></TD>
          <TD> <CENTER>
              <STRONG> <A href="download/ttt2003_v1.exe">DOWNLOAD</A></STRONG> 
            </CENTER></TD>
        </TR>
      </TABLE>
      <H1>Support</H1>
      <P>For any technical support, write to <A href="mailto:ttt@dicelords.com">ttt@dicelords.com</A>. 
        We promise to take reasonable efforts to answer all your queries.</P>
      <HR size="1" noshade>
    </TD>
  </TR>
</TABLE>
</BODY>
</HTML>
