Equisys Zetafax Microsite.
--------------------------

The purpose of the file 'linkpage.htm' is to provide a logo,
some introductory text and link code that can be incorporated into an
appropriate page within an ESP's website. The logo and text
link to the microsite. It is not intended that 'linkpage'
will be used as an actual page on your site. It is provided
as a container for the 'hyperlinked' logo, text and HTML code.

The folder 'equisys_microsite' and all its contents should be saved
in the same folder where the contents from 'linkpage.htm' are
eventually saved.

The microsite contains a brief overview of Zetafax,
there are links on the page to the Equisys main site (www.equisys.com).
The links take you to the following sections of our site:
 
* Zetafax benefits 
* Zetafax add on
* Zetafax on-line demonstration 
* Request a trial CD 
* Zetafax marketing collateral

